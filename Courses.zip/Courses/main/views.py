from django.shortcuts import render,  redirect
from django.contrib import messages
from .models import Courses
# Create your views here.
def index(request):
    context = {
        'all_courses': Courses.objects.all()
    }
    return render(request, 'index.html', context)

def create(request):
    errors = Courses.objects.course_validator(request.POST)
    if len(errors) > 0:
        for key, value in errors.items():
            messages.error(request, value)
        return redirect('/')
    if request.method == 'POST':
        Courses.objects.create(
            name=request.POST['name'],
            desc=request.POST['desc'],
        )
        return redirect('/')
    return redirect('/')

def remove(request, course_id):
    context = {
        'course': Courses.objects.get(id=course_id)
    }
    return render(request, 'remove.html', context)

def delete(request, course_id):
    delete = Courses.objects.get(id=course_id)
    delete.delete()
    return redirect('/')